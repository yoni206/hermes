package mathsat;

public interface AllSatModelCallback {
    public int callback(long[] model);
}
