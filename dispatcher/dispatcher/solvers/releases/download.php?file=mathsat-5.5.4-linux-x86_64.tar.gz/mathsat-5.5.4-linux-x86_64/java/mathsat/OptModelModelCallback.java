package mathsat;

public interface OptModelModelCallback {
    public int callback(long env, long it, long jt);
}
